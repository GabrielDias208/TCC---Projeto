﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define p = Character("Protagonista", color="#c8ffc8")

define n = Character("??????", color="#FFFFFF")


# The game starts here.

label start:

    #primeira cena
    scene trans with fade

    n "(Foi a uma semana...)"

    n "(Nós acordamos atrasados e fomos correndo ao local da prova)"

    scene out with fade

    p "Bom, aqui estou eu."

    p "Provavelmente o dia mais infernal da minha vida"

    p "O ENEM!!!!! O MAIOR TERROR DE TODOS OS ETECANOS!!!"

    p "Merda, esqueci minha caneta azul..."

    p "Bom, vai com a preta mesmo, fazer o que né"

    p "MEU DEUS OLHA A HORA"
    p "Melhor eu ir antes que fique pra fora"
    #entrou na escola

    scene trans with fade

    n "(o protagonista entrou na escola, e viu um monte de gente correndo, gritando, e se desesperando)"

    scene bg_tela2 with fade

    p "MEU PAI AMADO DO CÉU,TEM TANTA GENTE ASSIM???"

    p "Parece que o mundo vai acabar, tem gente gritando, chorando, e correndo pra todo lado"
    
    p "(melhor eu ir para a sala logo...)"

    n "(um tempo depois...)"
    
    p "(aonde fica a sala?)"

    p "(tem tanta gente aqui, eu mal consigo ouvir meus pensamentos)"

    p "(Ah droga, não tô achando a porra da sala...)"

    p "( me aproximo de alguem e digo: )"

    p "Com licença, você sabe onde fica a sala 6?"

    n "EU TAMBÉM QUERO SABER CARA!! ME AJUDAAAAAAA"

    p "(malucão...)"

    scene classe with fade

    p "Oia, achamos a sala"

    p "(não acredito que esse malucão tava certo)"

    p "Bom mano, já vou indo pra minha mesa, boa sorte!"

    n "Valeu esquisitão, boa sorte pra você também!!"

    p "(ah vai toma no cu )"

    scene bg_mesa with fade
    n "A beta acaba por aqui..."


    # This ends the game.

    return